# Job Post Application
Welcome to the Job Post Application! This web application allows students to find available job listings posted by employers. Employers can register, create job postings, and connect with potential candidates.

## Overview
The Job Post Application is built using Ruby on Rails, a powerful web application framework known for its simplicity, flexibility, and rapid development capabilities. The application utilizes PostgreSQL for the database, providing a reliable and efficient storage solution.

## Project Goals and Objectives

- Facilitate job search for students by providing a platform to browse and apply for job postings.
- Simplify the process for employers to create and manage job listings.
- Enhance the overall user experience with a responsive and intuitive interface.
- Promote efficient communication between students and employers during the hiring process.

## Scope of the Project

The project includes the following main features:
- Student registration and profile creation.
- Employer registration and profile creation.
- Job posting and search functionality.
- Display of student profiles and job listings.
- Responsive user interface for seamless interaction.

## Local Setup
To set up the Job Post Application locally, follow these steps:


### Install dependencies:

```
cd jobpostapp
bundle install
```
### Set up the database:

```
rails db:create
rails db:migrate
```
### Start the Rails server:


```
rails server
```
Access the application at `http://localhost:3000` in your web browser.

## Setup using Dockerfile

> Note: You should have Docker installed in your system already. 

- Open CLI where Dockerfile exists and execute the following command to build the docker image:

```
docker build -t jobpost .
```

- Then execute the `jobpost` container using:

```
docker run -it -p 3000:3000 jobpost  bash
```

- Once you're inside Docker container, execute the following command to start PostgreSQL:

```
service postgresql start
```

- Go to the `/jobpostapp` directory and set up the application:

```
cd /jobpostapp
bin/setup
```

- Execute the Rails server using:

```
bundle exec rails s -b 0.0.0.0
```

> Access the application at `http://localhost:3000` in your web browser.

## Project Plan
### Timeline of Developing Features/Requirements
- Front-end/User Interface Development (Jan2024):

   - Designing and implementing user interface components.
   - Creating responsive layouts for different screen sizes.
   - Implementing client-side interactivity.
- Back-end/Server-Side Development (Feb2024 - 24March2024):

   - Setting up models and associations for students, employers, and jobs.
   - Implementing authentication and authorization using Devise.
   - Building controllers for handling user actions and data manipulation.
### Milestones
- Milestone 1: Completion of Front-end Development 
- Milestone 2: Backend Implementation and User Authentication 
- Milestone 3: Job Posting and Search Functionality 
## User Guide
The Job Post Application allows users to:

- Register as a student or employer.
- Create and update their profiles with relevant information.
- Browse job listings and apply for positions.
- Post job listings and manage their listings.



## Choice of Tech Stack and Architecture
### Backend Framework:
- Ruby on Rails: Chosen for its robustness, convention-over-configuration approach, and vast ecosystem of gems for rapid development.
### Database:
- PostgreSQL: Selected for its reliability, performance, and support for advanced features like full-text search.
### Frontend Framework:
- Bootstrap with HTML/CSS/JavaScript: Utilized for its responsive design components and ease of use in creating a visually appealing UI.
### User Authentication:
- Devise: Implemented for user authentication and registration. Devise provides a full suite of authentication features, including user registration, login, logout, password reset, and account confirmation.
### Image Uploads:
- Active Storage: Utilized for managing file uploads, including profile photos for students and employers. Active Storage integrates seamlessly with cloud storage services like Amazon S3 and local disk storage.
### Search Functionality:
- PostgreSQL Full-Text Search: Implemented for efficient and flexible searching of job listings and student profiles. PostgreSQL's full-text search capabilities allow for quick and relevant search results.
### Deployment:
- Heroku: Recommended for deployment due to its ease of use and seamless integration with Rails applications. Heroku provides a straightforward deployment process and includes various add-ons for monitoring, logging, and more.
### Project Architecture:
- MVC Architecture: The application follows the Model-View-Controller (MVC) architectural pattern.
- Model: Represents the data and business logic.
- View: Handles the presentation layer with HTML templates and embedded Ruby (ERB) for rendering dynamic content.
- Controller: Manages the application flow, handles user requests, and interacts with models.
## Features
- Student Registration and Profiles: Students can register, create profiles, and include details such as full name, contact information, key skills, academic history, and work experience.
- Employer Registration and Profiles: Employers can register, create profiles, and include details such as company name, contact information, and upload a company photo.
- Job Postings: Employers can create job postings with details such as job title, location, description, and requirements.
- Search Jobs: Students can search for available job listings based on keywords and location.
- Student Directory: Display all student profiles with their names, key skills, and additional details in a card layout.
- Responsive Design: The application is designed to be responsive, ensuring optimal user experience across devices.

## Legal and Ethical Considerations
- Ensure compliance with data protection regulations.
- Respect user privacy and confidentiality.
- Obtain necessary permissions for using third-party services or libraries.

## Risk Assessment
- Identified Risks:

  - Data security vulnerabilities.
  - Server downtime affecting availability.
  - Compatibility issues with different web browsers.

- Mitigation Strategies:

  - Implement secure authentication mechanisms.
  - Regular backups and monitoring of server performance.
  - Conduct thorough testing on multiple browsers and devices.
## Future Considerations for Scaling
- Implementing caching mechanisms for improved performance.
- Horizontal scaling with load balancers for handling increased traffic.
- Introducing background job processing for time-intensive tasks.



### Contributions
Contributions to the Job Post Application are welcome! If you'd like to contribute, please follow these steps:

- Fork the repository.
- Create a new branch (git checkout -b feature/new-feature).
- Make your changes and commit them (git commit -am 'Add new feature').
- Push to the branch (git push origin feature/new-feature).
- Create a new Pull Request.
