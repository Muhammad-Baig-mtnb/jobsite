require "test_helper"

class JobSearchesControllerTest < ActionDispatch::IntegrationTest
  test "should get search" do
    get job_searches_search_url
    assert_response :success
  end
end
