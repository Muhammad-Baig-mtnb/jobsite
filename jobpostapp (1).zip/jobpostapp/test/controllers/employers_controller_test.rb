require "test_helper"

class EmployersControllerTest < ActionDispatch::IntegrationTest
  test "should get dashboard" do
    get employers_dashboard_url
    assert_response :success
  end
end
