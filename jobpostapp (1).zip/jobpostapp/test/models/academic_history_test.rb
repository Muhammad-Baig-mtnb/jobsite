require "test_helper"

class AcademicHistoryTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
