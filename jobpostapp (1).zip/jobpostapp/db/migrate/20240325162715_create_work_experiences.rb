class CreateWorkExperiences < ActiveRecord::Migration[7.0]
  def change
    create_table :work_experiences do |t|
      t.string :position
      t.string :company
      t.text :responsibilities
      t.string :duration
      t.belongs_to :student, null: false, foreign_key: true

      t.timestamps
    end
  end
end
