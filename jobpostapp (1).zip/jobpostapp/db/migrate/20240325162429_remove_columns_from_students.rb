class RemoveColumnsFromStudents < ActiveRecord::Migration[7.0]
  def change
    remove_column :students, :key_skills, :string
    remove_column :students, :academic_timeline, :string
    remove_column :students, :work_experience_timeline, :string
  end
end
