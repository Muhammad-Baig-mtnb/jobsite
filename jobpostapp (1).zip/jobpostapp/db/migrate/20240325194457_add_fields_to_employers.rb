class AddFieldsToEmployers < ActiveRecord::Migration[7.0]
  def change
    add_column :employers, :company_name, :string
    add_column :employers, :website, :string
  end
end
