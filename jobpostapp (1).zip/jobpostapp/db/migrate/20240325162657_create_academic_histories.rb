class CreateAcademicHistories < ActiveRecord::Migration[7.0]
  def change
    create_table :academic_histories do |t|
      t.string :institution
      t.string :field_of_study
      t.integer :start_year
      t.integer :end_year
      t.belongs_to :student, null: false, foreign_key: true

      t.timestamps
    end
  end
end
