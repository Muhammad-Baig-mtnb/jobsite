class AddFieldsToStudents < ActiveRecord::Migration[7.0]
  def change
    add_column :students, :full_name, :string
    add_column :students, :photo, :string
    add_column :students, :phone_number, :string
    add_column :students, :key_skills, :text
    add_column :students, :academic_timeline, :text
    add_column :students, :work_experience_timeline, :text
  end
end
