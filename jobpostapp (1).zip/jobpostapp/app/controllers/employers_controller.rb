class EmployersController < ApplicationController
  before_action :authenticate_employer!

  def dashboard
    @employer = current_employer
  end
end
