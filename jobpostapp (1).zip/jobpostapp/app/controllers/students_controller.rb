class StudentsController < ApplicationController
  before_action :authenticate_student!, only: :dashboard

  def dashboard
    @student = current_student
    @key_skills = @student.key_skills
    @academic_histories = @student.academic_histories
    @work_experiences = @student.work_experiences

  end

  def index

    @students = if params[:search].present?
                  Student.search(params[:search])
                else
                  Student.all
                end
    
    ActiveStorage::Current.url_options = { host: request.base_url }
  end

end
