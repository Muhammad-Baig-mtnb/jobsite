class JobsController < ApplicationController

    before_action :authenticate_employer, only: :create

    def create
      @job = Job.new(job_params)
      
      if @job.save
        redirect_to root_path, notice: "Job enlisted successfully"
      else
        render :new
      end
    end


    def search
        @keywords = params[:keywords]
        @location = params[:location]
        @jobs = Job.search(@keywords, @location)
        render 'jobs/index'
    end
  
    private
  
    def job_params
      params.require(:job).permit(:title, :location, :description)
    end
end
  