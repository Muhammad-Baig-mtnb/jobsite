class HomeController < ApplicationController
  def index
    if student_signed_in?
      redirect_to search_jobs_path
    elsif employer_signed_in?
      redirect_to students_index_path
    else
      redirect_to main_login_path
    end
  end
end
