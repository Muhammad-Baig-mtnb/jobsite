class WorkExperience < ApplicationRecord
  belongs_to :student
end
