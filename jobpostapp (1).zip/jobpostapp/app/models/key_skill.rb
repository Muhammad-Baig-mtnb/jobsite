class KeySkill < ApplicationRecord
  belongs_to :student
end
