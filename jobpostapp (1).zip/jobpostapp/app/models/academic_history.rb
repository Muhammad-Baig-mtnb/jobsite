class AcademicHistory < ApplicationRecord
  belongs_to :student
end
