class Job < ApplicationRecord
    validates :title, presence: true
    validates :location, presence: true
    validates :description, presence: true
  
    def self.search(keywords, location)
      jobs = Job.all
      jobs = jobs.where("title ILIKE ? OR description ILIKE ?", "%#{keywords}%", "%#{keywords}%") if keywords.present?
      jobs = jobs.where("location ILIKE ?", "%#{location}%") if location.present?
      jobs
    end
  end
  