class Student < ApplicationRecord
  # Include default devise modules. Others available are:
  # :confirmable, :lockable, :timeoutable, :trackable and :omniauthable
  devise :database_authenticatable, :registerable,
         :recoverable, :rememberable, :validatable

  # Add additional fields
  validates :full_name, presence: true
  validates :email, presence: true
  validates :phone_number, presence: true

  has_one_attached :photo

  has_many :key_skills, dependent: :destroy
  has_many :academic_histories, dependent: :destroy
  has_many :work_experiences, dependent: :destroy

  accepts_nested_attributes_for :key_skills, allow_destroy: true
  accepts_nested_attributes_for :academic_histories, allow_destroy: true
  accepts_nested_attributes_for :work_experiences, allow_destroy: true

  def self.search(query)
    where("full_name LIKE ? OR id IN (SELECT student_id FROM key_skills WHERE name LIKE ?)", "%#{query}%", "%#{query}%")
  end
  

end
