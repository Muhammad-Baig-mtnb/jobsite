Rails.application.routes.draw do

  get 'employers/dashboard'
  get 'students/dashboard'
  get 'students/index'
  # For Students
  get 'student_dashboard', to: 'students#dashboard', as: 'student_dashboard'

  # For Employers
  get 'employer_dashboard', to: 'employers#dashboard', as: 'employer_dashboard'
  get 'main_login', to: 'home#main_login'


  devise_for :employers, controllers: {
    registrations: 'employers/registrations'
  }
  devise_for :students, controllers: { 

    registrations: "students/registrations" 
  }
  root 'home#index'

  resources :jobs, only: [:create]
  get '/search_jobs', to: 'jobs#search', as: 'search_jobs'


  # Define your application routes per the DSL in https://guides.rubyonrails.org/routing.html

  # Defines the root path route ("/")
  # root "articles#index"
end
